[PSCustomObject]@{
'env:UserName'	= $env:USERNAME
'whoami'	= whoami.exe
'GetCurrent'	= [Security.Principal.WindowsIdentity]::GetCurrent().Name
} | Format-List | Out-File -FilePath c:\demo\whoami.txt